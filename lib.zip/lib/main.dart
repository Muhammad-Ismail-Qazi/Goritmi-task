import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:todo_desktop_app/feature/auth/presentation/signup_screen.dart';
import 'package:todo_desktop_app/feature/auth/provider/auth_provider.dart';

void main() {
  sqfliteFfiInit(); // Required to use SQLite on Windows
  databaseFactory = databaseFactoryFfi; // Set global factory to FFI
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(create: (_)=> AuthProvider(), child:  MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),
      home: SignupScreen(),
    ),);
  }
}
