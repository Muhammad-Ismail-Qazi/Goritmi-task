// lib/features/auth/provider/auth_provider.dart
import 'package:flutter/material.dart';
import '../../auth/data/auth_repository_impl.dart';
import '../../auth/domain/user_model.dart';

class AuthProvider with ChangeNotifier {
  final AuthRepositoryImpl _authRepository = AuthRepositoryImpl();

  UserModel? get user => _authRepository.currentUser;

  Future<String?> login(String email, String password) async {
    final result = await _authRepository.login(email, password);
    if (result != null) {
      notifyListeners();
      return null;
    } else {
      return "Invalid credentials";
    }
  }

  Future<String?> signup(String email, String password) async {
    final error = await _authRepository.signup(email, password);
    return error;
  }

  void logout() {
    _authRepository.logout();
    notifyListeners();
  }
}
