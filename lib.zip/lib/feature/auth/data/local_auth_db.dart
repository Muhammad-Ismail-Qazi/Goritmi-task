import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import '../../../shared/services/database_service.dart';
import '../domain/user_model.dart';

class LocalAuthDataSource {

  Future<void> registerUser(UserModel user) async {
    final db = await DatabaseService().database;

    await db.insert(
      'users',
      user.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<UserModel?> loginUser(String email, String password) async {
    final db = await DatabaseService().database;

    final result = await db.query(
      'users',
      where: 'email = ? AND password = ?',
      whereArgs: [email, password],
    );

    if (result.isNotEmpty) {
      return UserModel.fromMap(result.first);
    }
    return null;
  }
}