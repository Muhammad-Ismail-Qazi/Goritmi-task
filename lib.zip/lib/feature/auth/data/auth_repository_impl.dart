// lib/features/auth/data/auth_repository_impl.dart
import '../../auth/domain/auth_repository.dart';
import '../../auth/domain/user_model.dart';
import 'local_auth_db.dart';

class AuthRepositoryImpl implements AuthRepository {
  final LocalAuthDataSource _dataSource = LocalAuthDataSource();
  UserModel? _user;

  @override
  Future<String?> signup(String email, String password) async {
    try {
      await _dataSource.registerUser(UserModel(email: email, password: password));
      return null;
    } catch (_) {
      return "User already exists or error occurred.";
    }
  }

  @override
  Future<UserModel?> login(String email, String password) async {
    final result = await _dataSource.loginUser(email, password);
    _user = result;
    return result;
  }

  @override
  void logout() {
    _user = null;
  }

  @override
  UserModel? get currentUser => _user;
}
